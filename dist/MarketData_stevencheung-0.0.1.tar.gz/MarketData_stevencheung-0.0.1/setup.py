import setuptools

setuptools.setup(     
    name="MarketData_stevencheung",     
    version="0.0.1",
    python_requires=">=3.6",   
    packages=["market_data"],
)
