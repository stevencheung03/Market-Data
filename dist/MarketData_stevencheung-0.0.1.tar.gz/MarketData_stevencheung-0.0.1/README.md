Used yfinance to get market data.
